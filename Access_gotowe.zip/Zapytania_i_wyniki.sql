-- B01_1000
INSERT INTO ksiazki (idk, tytul, autor, rokw, wydawnictwo, gatunek, stan, cena)
VALUES (1000, 'Intronizacja', 'Zweig Arnold', 1953, 'Suchan', 'Melodramat', 'Jest', 35);

-- B01_1001
INSERT INTO ksiazki (idk, tytul, autor, rokw, wydawnictwo, gatunek, stan, cena)
VALUES (1001, 'Maria Stuart', 'Zweig Stefan', 1954, 'Suchan', 'Obyczajowa', 'Jest', 36);

-- B01_1002
INSERT INTO ksiazki (idk, tytul, autor, rokw, wydawnictwo, gatunek, stan, cena)
VALUES (1002, 'Maria Antonina', 'Zweig Stefan', 1955, 'Suchan', 'Poradnik', 'Jest', 37);

-- B01_1003
INSERT INTO ksiazki (idk, tytul, autor, rokw, wydawnictwo, gatunek, stan, cena)
VALUES (1003, 'Przedwiośnie', 'Żeromski Stefan', 1956, 'Suchan', 'Historia', 'Jest', 38);

-- B01_1004
INSERT INTO ksiazki (idk, tytul, autor, rokw, wydawnictwo, gatunek, stan, cena)
VALUES (1004, 'Przedwiośnie', 'Żeromski Stefan', 1957, 'Suchan', 'Atlas', 'Jest', 39);

-- B01_1005
INSERT INTO ksiazki (idk, tytul, autor, rokw, wydawnictwo, gatunek, stan, cena)
VALUES (1005, 'Przedwiośnie', 'Żeromski Stefan', 1958, 'Suchan', 'Historia', 'Jest', 40);

-- B02_Zmien_gatunek
UPDATE ksiazki
SET gatunek = 'horror/thriller'
WHERE gatunek='horror';

-- B03_Zmien_stan
UPDATE ksiazki
SET stan = 'do wypożyczenia'
WHERE stan='jest';

-- B04_PWN_cena_plus_10proc
UPDATE ksiazki
SET cena = cena*1.1
WHERE wydawnictwo='PWN';

-- B05_Po_2000_cena_minus_20proc
UPDATE ksiazki
SET cena = cena*0.8
WHERE rokw>2000;

-- B06_Kraszewski_pelne_imiona
UPDATE ksiazki
SET autor = 'Kraszewski Józef Ignacy'
WHERE autor='Kraszewski J.I.';

-- B07_Przed_1970_na_miejscu
UPDATE ksiazki
SET stan = 'Do korzystania na miejscu'
WHERE rokw<1970 AND stan='do wypożyczenia';

-- B08_Usun_przed_1960
DELETE *
FROM ksiazki
WHERE rokw<1960;

-- B09_Usun_Fox
DELETE *
FROM ksiazki
WHERE wydawnictwo='Fox';

-- B10_Usun_niewypozyczone_drogie
DELETE *
FROM ksiazki
WHERE stan<>'Wypożyczona' AND cena>30;

-- B11_Usun_atlasy_Bosch
DELETE *
FROM ksiazki
WHERE gatunek='Atlas' AND wydawnictwo='Bosch';

-- P01_Usun_utwory_Udar
DELETE *
FROM Utwory
WHERE [IDpłyty] IN (SELECT [IDpłyty] FROM [Płyty] WHERE [Tytul_plyty]='Udar');

-- P02_Usun_utwory_Virgin
DELETE *
FROM Utwory
WHERE [IDpłyty] IN (SELECT [IDpłyty] FROM [Płyty] WHERE [Wytwórnia]='Virgin');

-- P03_Usun_utwory_Dzem
DELETE *
FROM Utwory
WHERE [IDpłyty] IN (SELECT [IDpłyty] FROM [Płyty] WHERE [IDwykonawcy] IN (SELECT [IDwykonawcy] FROM [Wykonawcy] WHERE [Wykonawca]='Dżem'));

-- P04_Usun_plyty_Dzem
DELETE *
FROM [Płyty]
WHERE [IDwykonawcy] IN (SELECT [IDwykonawcy] FROM [Wykonawcy] WHERE [Wykonawca]='Dżem');

-- Wykonano B01_1000_Dodaj_ksiazke: 1 rekordów

-- Wykonano B01_1001_Dodaj_ksiazke: 1 rekordów

-- Wykonano B01_1002_Dodaj_ksiazke: 1 rekordów

-- Wykonano B01_1003_Dodaj_ksiazke: 1 rekordów

-- Wykonano B01_1004_Dodaj_ksiazke: 1 rekordów

-- Wykonano B01_1005_Dodaj_ksiazke: 1 rekordów

-- Wykonano B02_Zmien_gatunek: 27 rekordów

-- Wykonano B03_Zmien_stan: 268 rekordów

-- Wykonano B04_PWN_cena_plus_10proc: 27 rekordów

-- Wykonano B05_Po_2000_cena_minus_20proc: 67 rekordów

-- Wykonano B06_Kraszewski_pelne_imiona: 4 rekordów

-- Wykonano B07_Przed_1970_na_miejscu: 83 rekordów

-- Wykonano B08_Usun_przed_1960: 111 rekordów

-- Wykonano B09_Usun_Fox: 12 rekordów

-- Wykonano B10_Usun_niewypozyczone_drogie: 77 rekordów

-- Wykonano B11_Usun_atlasy_Bosch: 1 rekordów

-- Wykonano P01_Usun_utwory_Udar: 9 rekordów

-- Wykonano P02_Usun_utwory_Virgin: 24 rekordów

-- Wykonano P03_Usun_utwory_Dzem: 12 rekordów

-- Wykonano P04_Usun_plyty_Dzem: 1 rekordów